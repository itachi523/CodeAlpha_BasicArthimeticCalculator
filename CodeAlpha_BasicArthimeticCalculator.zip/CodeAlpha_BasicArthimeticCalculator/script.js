const display = document.getElementById("display");

const liveResult = document.getElementById("liveResult");

const historyBox = document.getElementById("history");

const themeToggle = document.getElementById("themeToggle");

const calculator = document.querySelector(".calculator");

const ai = document.getElementById("aiMessage");

let history = [];

function appendValue(value){

  display.value += value;

  updateLiveResult();

  playClickSound();

  if(value === "+"){
    calculator.style.boxShadow = "0 0 30px #00bfff";
  }

  if(value === "-"){
    calculator.style.boxShadow = "0 0 30px #ff6b6b";
  }

  if(value === "*"){
    calculator.style.boxShadow = "0 0 30px #9b59b6";
  }

}

function clearDisplay(){

  display.value = "";

  liveResult.innerHTML = "= 0";

  ai.innerHTML = "Cleared 🧹";

  playClickSound();

}

function deleteLast(){

  display.value = display.value.slice(0,-1);

  updateLiveResult();

  playClickSound();

}

function calculate(){

  try{

    if(display.value === "5318008"){

      display.value = "😂";

      ai.innerHTML = "Secret Found 🥚";

      return;

    }

    if(display.value.includes('/0')){

      display.value = "Cannot divide by zero";

      ai.innerHTML = "Nice try 😂";

      return;

    }

    let expression = display.value;

    let result = eval(expression);

    history.push(`${expression} = ${result}`);

    updateHistory();

    display.value = result;

    liveResult.innerHTML = `= ${result}`;

    playEqualSound();

    if(result > 100000){

      ai.innerHTML = "Big numbers 😎";

    }

    else if(expression === "1+1"){

      ai.innerHTML = "Classic 😂";

    }

    else{

      ai.innerHTML = "Calculation Complete ✅";

    }

  }

  catch{

    display.value = "Invalid";

    ai.innerHTML = "Oops 😅";

  }

}

function updateLiveResult(){

  try{

    if(display.value !== ""){

      liveResult.innerHTML = `= ${eval(display.value)}`;

    }

    else{

      liveResult.innerHTML = "= 0";

    }

  }

  catch{

    liveResult.innerHTML = "...";

  }

}

function updateHistory(){

  historyBox.innerHTML = history
  .slice(-3)
  .reverse()
  .join("<br>");

}

window.addEventListener("keydown",(e)=>{

  const key = e.key;

  if(!isNaN(key) || "+-*/.%".includes(key)){

    appendValue(key);

  }

  else if(key === "Enter"){

    calculate();

  }

  else if(key === "Backspace"){

    deleteLast();

  }

  else if(key === "Escape"){

    clearDisplay();

  }

});

let darkMode = true;

themeToggle.addEventListener("click",()=>{

  darkMode = !darkMode;

  if(darkMode){

    /* DARK MODE */

    document.body.style.background =
    "linear-gradient(135deg,#0f172a,#1e293b,#111827)";

    calculator.style.background =
    "rgba(15,23,42,0.7)";

    display.style.background = "#111827";

    display.style.color = "white";

    document.querySelectorAll("button").forEach((btn)=>{

      if(
        !btn.classList.contains("operator") &&
        !btn.classList.contains("special") &&
        !btn.classList.contains("equal")
      ){

        btn.style.background = "#1e293b";

        btn.style.color = "white";
      }

    });

    document.querySelector(".top-bar h2").style.color = "white";

    document.getElementById("clock").style.color = "white";

    historyBox.style.color = "white";

    liveResult.style.color = "white";

    ai.style.color = "white";

    themeToggle.innerHTML = "☀️";

  }

  else{

    /* LIGHT MODE */

    document.body.style.background =
    "linear-gradient(135deg,#f5f7fa,#c3cfe2)";

    calculator.style.background =
    "rgba(255,255,255,0.25)";

    display.style.background =
    "rgba(255,255,255,0.6)";

    display.style.color = "#111";

    document.querySelectorAll("button").forEach((btn)=>{

      if(
        !btn.classList.contains("operator") &&
        !btn.classList.contains("special") &&
        !btn.classList.contains("equal")
      ){

        btn.style.background =
        "rgba(255,255,255,0.7)";

        btn.style.color = "#111";
      }

    });

    document.querySelector(".top-bar h2").style.color = "#111";

    document.getElementById("clock").style.color = "#333";

    historyBox.style.color = "#333";

    liveResult.style.color = "#333";

    ai.style.color = "#333";

    themeToggle.innerHTML = "🌙";

  }

});

function playClickSound(){

  const sound = new Audio(
    "https://www.soundjay.com/buttons/sounds/button-09.mp3"
  );

  sound.volume = 0.2;

  sound.play();

}

function playEqualSound(){

  const sound = new Audio(
    "https://www.soundjay.com/buttons/sounds/button-4.mp3"
  );

  sound.volume = 0.3;

  sound.play();

}

document.addEventListener("mousemove",(e)=>{

  let x = (window.innerWidth / 2 - e.pageX) / 25;

  let y = (window.innerHeight / 2 - e.pageY) / 25;

  calculator.style.transform =
  `rotateY(${x}deg) rotateX(${-y}deg)`;

});

const buttons = document.querySelectorAll("button");

buttons.forEach((button)=>{

  button.addEventListener("mousemove",(e)=>{

    const x = e.offsetX / 10;

    const y = e.offsetY / 10;

    button.style.transform =
    `translate(${x}px,${y}px)`;

  });

  button.addEventListener("mouseleave",()=>{

    button.style.transform = "translate(0,0)";

  });

});

function updateClock(){

  const now = new Date();

  let time = now.toLocaleTimeString();

  document.getElementById("clock").innerHTML = time;

}

setInterval(updateClock,1000);

updateClock();

tsParticles.load("particles-js",{

  particles:{

    number:{
      value:40
    },

    size:{
      value:2
    },

    move:{
      enable:true,
      speed:1
    },

    opacity:{
      value:0.3
    }

  }

});